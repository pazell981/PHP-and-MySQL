<!DOCTYPE HTML>
<html>
<head>
	<meta charset="UTF-8">
	<title>PHP and MySQL - Advanced 3</title>
	<meta name="description" content="PHP and MySQL - 07/07/14 - Advanced 3">
	<link rel="stylesheet" type="text/css" href="main.css.php">
	<script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js"></script>
	<script type="text/javascript" src="main.js.php"></script>
</head>
<body>
<div id="container">
	<div id="wrapper">
		<h1>Advanced 3 - PHP creating CSS, javascript and an image</h1>
		<h2>Wow!</h2>
		<p>I had no idea you could use PHP to create a CSS file or any other files than HTML!!!</p>
		<img src="phpimage.php" alt="Image created by a PHP script">
	</div>
</div>
</body>
</html>